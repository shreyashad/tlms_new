from django.shortcuts import render

from accounts.authentication import CustomCASAuthentication
from course.serializers import *
from course.models import *
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework.permissions import IsAuthenticated
from rest_framework import status, generics
# Create your views here.


class DifficultyLevelListCreateView(generics.ListCreateAPIView):
    queryset = DifficltyLevel.objects.all()
    serializer_class = DifficultyLevelSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class DifficultyLevelDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = DifficltyLevel.objects.all()
    serializer_class = DifficultyLevelSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


# for Course Category
class CourseCategoryListView(generics.ListAPIView):
    queryset = CourseCategory.objects.all()
    serializer_class = CourseCategorySerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class CourseCategoryCreateView(generics.CreateAPIView):
    queryset = CourseCategory.objects.all()
    serializer_class =  CourseCategorySerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class CourseCategoryDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = CourseCategory.objects.all()
    serializer_class = CourseCategorySerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


# for Course
class CourseListView(generics.ListAPIView):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class CourseCreateView(generics.CreateAPIView):
    queryset = Course.objects.all()
    serializer_class =  CourseSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class CourseDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Course.objects.all()
    serializer_class = CourseSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


# for Module
class ModuleListView(generics.ListAPIView):
    queryset = Module.objects.all()
    serializer_class = ModuleSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class ModuleCreateView(generics.CreateAPIView):
    queryset = Module.objects.all()
    serializer_class =  ModuleSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class ModuleDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Module.objects.all()
    serializer_class = ModuleSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


# for VideoLesson

class VideoLessonListView(generics.ListAPIView):
    queryset = VideoLesson.objects.all()
    serializer_class = VideoLessonSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class VideoLessonCreateView(generics.CreateAPIView):
    queryset = VideoLesson.objects.all()
    serializer_class =  VideoLessonSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class VideoLessonDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = VideoLesson.objects.all()
    serializer_class = VideoLessonSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


# for Material

class MaterialListView(generics.ListAPIView):
    queryset = Material.objects.all()
    serializer_class = MaterialSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class MaterialCreateView(generics.CreateAPIView):
    queryset = Material.objects.all()
    serializer_class =  MaterialSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class MaterialDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = Material.objects.all()
    serializer_class = MaterialSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)

