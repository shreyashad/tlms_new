from django.urls import path
from .views import *

urlpatterns = [
    path('difficulty-level-list/', DifficultyLevelListCreateView.as_view(), name='difficulty-level-list'),
    path('difficulty-level/<uuid:pk>/details/', DifficultyLevelDetailView.as_view(), name='difficulty-level-details'),
    path('course-category-list/', CourseCategoryListView.as_view(), name='course-category-list'),
    path('create-course-category/', CourseCategoryCreateView.as_view(), name='create-course-category'),
    path('course-category/<uuid:pk>/details/', CourseCategoryDetailView.as_view(), name='course-category-details'),
    path('course-list/', CourseListView.as_view(), name='course-list'),
    path('create-course/', CourseCreateView.as_view(), name='create-course'),
    path('course/<uuid:pk>/details/', CourseDetailView.as_view(), name='course-details'),
    path('module-list/', ModuleListView.as_view(), name='module-list'),
    path('create-module/', ModuleCreateView.as_view(), name='create-module'),
    path('module/<uuid:pk>/details/', ModuleDetailView.as_view(), name='module-details'),
    path('video-lesson-list/', VideoLessonListView.as_view(), name='video-lesson-list'),
    path('create-video-lesson', VideoLessonCreateView.as_view(), name='create-video-lesson'),
    path('video-lesson/<uuid:pk>/details/', VideoLessonDetailView.as_view(), name='video-lesson-details'),
    path('material-list/', MaterialListView.as_view(), name='material-list'),
    path('create-material/', MaterialCreateView.as_view(), name='create-material'),
    path('material/<uuid:pk>/details/', MaterialDetailView.as_view(), name='material-details'),


]
