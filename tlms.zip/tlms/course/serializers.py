from rest_framework import serializers
from course.models import *

class DifficultyLevelSerializer(serializers.ModelSerializer):
    class Meta:
        model = DifficltyLevel
        fields = ['id', 'name', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']




class CourseCategorySerializer(serializers.ModelSerializer):
    class Meta:
        model = CourseCategory
        fields = ['id', 'name', 'description', 'image', 'category_status', 'created_at', 'updated_at', 'created_by',
                  'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class VideoLessonSerializer(serializers.ModelSerializer):

    class Meta:
        model = VideoLesson
        fields = ['id', 'title', 'description', 'image', 'status', 'created_at', 'updated_at', 'created_by',
                  'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class MaterialSerializer(serializers.ModelSerializer):
    class Meta:
        model = Material
        fields = ['id', 'title', 'description', 'image', 'status', 'created_at', 'updated_at', 'created_by',
                  'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class ModuleSerializer(serializers.ModelSerializer):
    video_lessons = VideoLessonSerializer(many=True, read_only=True)
    materials = MaterialSerializer(many=True, read_only=True)

    class Meta:
        model = Module
        fields = ['id', 'title', 'description', 'image', 'status', 'created_at', 'updated_at', 'created_by',
                  'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class CourseSerializer(serializers.ModelSerializer):

    class Meta:
        model = Course
        fields = ['id', 'title', 'description', 'image', 'status', 'created_at', 'updated_at', 'created_by',
                  'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class CourseDetailSerializer(serializers.ModelSerializer):
    modules = ModuleSerializer(many=True, read_only=True)

    class Meta:
        model = Course
        fields = "__all__"
        depth = 1



