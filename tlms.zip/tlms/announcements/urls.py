from django.urls import path
from .views import *
urlpatterns = [
    path('announcement-category-list/', AnnouncementCategoryListAPIView.as_view(), name='announcement-category-list'),
    path('create-announcement-category/', AnnouncementCategoryCreateAPIView.as_view(), name='create-announcement-category'),
    path('announcement-category/<uuid:pk>/details/', AnnouncementCategoryRetrieveUpdateDestroyAPIView.as_view(), name='announcement-category-details'),
    path('announcement-list/', AnnouncementListAPIView.as_view(), name='announcement-list'),
    path('create-announcement/', AnnouncementCreateAPIView.as_view(), name='create-announcement'),
    path('announcement/<uuid:pk>/details/', AnnouncementRetrieveUpdateDestroyAPIView.as_view(),name='announcement-details'),


]
