from django.db import models
from datetime import timedelta
from accounts.models import BaseModel
from course.models import Course
from django.core.exceptions import ValidationError

# Create your models here.
# class QuestionType(models.TextChoices):
#     MULTIPLE_CHOICE = 'Multiple Choice', 'Multiple Choice'
#     FILL_IN_THE_BLANKS = 'Fill in the Blanks', 'Fill in the Blanks'
#     TRUE_FALSE = 'True or False', 'True or False'
#     ORDERING = 'Ordering', 'Ordering'
#     SHORT_ANSWER = 'Short Answer', 'Short Answer'

class QuestionType(BaseModel):
    name = models.CharField(max_length=255, unique=True)

    def __str__(self):
        return self.name

class Quiz(BaseModel):
    title = models.CharField(max_length=250)
    course = models.ForeignKey(Course, related_name='quizzes', on_delete=models.CASCADE)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    duration = models.DurationField(help_text="Duration of the quiz in HH:MM:SS format", null=True, blank=True)
    description = models.TextField()
    total_marks = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    pass_marks = models.DecimalField(max_digits=5, decimal_places=2)

    def __str__(self):
        return self.title

    def clean(self):
        # Check for overlapping quizzes
        if self.start_time and self.end_time:
            overlapping_quizzes = Quiz.objects.filter(
                course=self.course,
                start_time__lt=self.end_time,
                end_time__gt=self.start_time
            )
            if overlapping_quizzes.exists():
                raise ValidationError('This quiz overlaps with another quiz for the same course.')

    def calculate_duration(self):
        """Calculate duration based on start and end time."""
        if self.start_time and self.end_time:
            return self.end_time - self.start_time
        return timedelta(0)

    def calculate_total_marks(self):
        """Calculate total marks based on the sum of marks of all questions."""
        return sum(question.marks for question in self.questions.all())

    def save(self, *args, **kwargs):
        # Calculate duration
        self.duration = self.calculate_duration()

        # Calculate total marks
        self.total_marks = self.calculate_total_marks()

        super().save(*args, **kwargs)



class Question(BaseModel):
    quiz = models.ForeignKey(Quiz, related_name='questions', on_delete=models.CASCADE)
    question_type = models.CharField(max_length=255)
    question = models.TextField()
    marks = models.DecimalField(max_digits=5, decimal_places=2)

    def __str__(self):
        return self.question



class MultipleChoiceOption(models.Model):
    question = models.ForeignKey(Question, related_name='options', on_delete=models.CASCADE)
    text = models.CharField(max_length=255)
    is_correct = models.BooleanField(default=False)

    def __str__(self):
        return self.text


class FillInTheBlanksAnswer(models.Model):
    question = models.ForeignKey(Question, related_name='answers', on_delete=models.CASCADE)
    correct_answer = models.CharField(max_length=255)

    def __str__(self):
        return self.correct_answer


class TrueFalseAnswer(models.Model):
    question = models.OneToOneField(Question, related_name='true_false_answer', on_delete=models.CASCADE)
    is_true = models.BooleanField()

    def __str__(self):
        return f"{'True' if self.is_true else 'False'}"

class OrderingItem(models.Model):
    question = models.ForeignKey(Question, related_name='ordering_items', on_delete=models.CASCADE)
    text = models.CharField(max_length=255)
    order = models.PositiveIntegerField()

    def __str__(self):
        return self.text

class ShortAnswerResponse(models.Model):
    question = models.ForeignKey(Question, related_name='short_answer_responses', on_delete=models.CASCADE)
    correct_response = models.TextField()

    def __str__(self):
        return self.correct_response


class StudentSubmission(BaseModel):
    quiz = models.ForeignKey(Quiz, related_name='submissions', on_delete=models.CASCADE)
    student_id = models.UUIDField()  # Reference to user's ID from auth_server
    submitted_at = models.DateTimeField(auto_now_add=True)
    marks_obtained = models.DecimalField(max_digits=5, decimal_places=2, null=True, blank=True)
    graded = models.BooleanField(default=False)

    def __str__(self):
        return f"Submission by {self.student_id} for {self.quiz.title}"


class StudentAnswer(BaseModel):
    submission = models.ForeignKey(StudentSubmission, related_name='answers', on_delete=models.CASCADE)
    question = models.ForeignKey(Question, related_name='student_answers', on_delete=models.CASCADE)
    answer_text = models.TextField()  # For storing text responses or selected option text

    def __str__(self):
        return f"Answer for {self.question.text}"