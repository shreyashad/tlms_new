from django.urls import path
from .views import *

urlpatterns = [
    path('question-type/', QuestionTypeListCreateView.as_view(), name='question-type'),
    path('question-type/<uuid:pk>/details/', QuestionTypeDetailView.as_view(), name='question-type-details'),
    path('quizzes-list/', QuizListAPIView.as_view(), name='quiz-list'),
    path('quizzes/create/', QuizCreateAPIView.as_view(), name='quiz-create'),
    path('quizzes/<int:pk>/details/', QuizDetailAPIView.as_view(), name='quiz-detail'),
    path('question-list/', QuestionListAPIView.as_view(), name='question-list'),
    path('question/create/', QuestionCreateAPIView.as_view(), name='question-create'),
    path('question/<int:pk>/details/', QuestionDetailAPIView.as_view(), name='question-detail'),
    path('multiple-choice/', MultipleChoiceListAPIView.as_view(), name='multiple-choice/'),
    path('multiple-choice/create/', MultipleChoiceCreateAPIView.as_view(), name='multiple-choice-create'),
    path('multiple-choice/<int:pk>/details/', MultipleChoiceDetailAPIView.as_view(), name='multiple-choice-detail'),
    path('fill-in-blanks/', FillInTheBlanksListAPIView.as_view(), name='fill-in-blanks/'),
    path('fill-in-blanks/create/', FillInTheBlanksCreateAPIView.as_view(), name='fill-in-blanks-create'),
    path('fill-in-blanks/<int:pk>/details/', FillInTheBlanksDetailAPIView.as_view(), name='fill-in-blanks-detail'),
    path('true-false/', TrueFalseListAPIView.as_view(), name='true-false/'),
    path('true-false/create/', TrueFalseCreateAPIView.as_view(), name='true-false-create'),
    path('true-false/<int:pk>/details/', TrueFalseDetailAPIView.as_view(), name='true-false-detail'),
    path('ordering-items/', OrderingItemListAPIView.as_view(), name='ordering-items/'),
    path('ordering-items/create/', OrderingItemCreateAPIView.as_view(), name='ordering-items-create'),
    path('ordering-items/<int:pk>/details/', OrderingItemDetailAPIView.as_view(), name='ordering-items-detail'),
    path('true-false/', ShortAnswerListAPIView.as_view(), name='true-false/'),
    path('true-false/create/', ShortAnswerCreateAPIView.as_view(), name='true-false-create'),
    path('true-false/<int:pk>/details/', ShortAnswerDetailAPIView.as_view(), name='true-false-detail'),
    path('true-false/', TrueFalseListAPIView.as_view(), name='true-false/'),
    path('true-false/create/', TrueFalseCreateAPIView.as_view(), name='true-false-create'),
    path('true-false/<int:pk>/details/', TrueFalseDetailAPIView.as_view(), name='true-false-detail'),

]