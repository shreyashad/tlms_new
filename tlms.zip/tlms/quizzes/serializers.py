from rest_framework import serializers
from quizzes.models import *

class QuestionTypeSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuestionType
        fields = ['id', 'name', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']



class QuizSerializer(serializers.ModelSerializer):
    class Meta:
        model = Quiz
        fields = ['id', 'title','course','start_time' ,'end_time','duration','description','total_marks','pass_marks','created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']

    def validate(self, attrs):
        # Custom validation to check overlapping quizzes
        start_time = attrs.get('start_time')
        end_time = attrs.get('end_time')
        course = attrs.get('course')

        if start_time and end_time and start_time >= end_time:
            raise serializers.ValidationError("Start time must be before end time.")

        # Check for overlapping quizzes
        overlapping_quizzes = Quiz.objects.filter(
            course=course,
            start_time__lt=end_time,
            end_time__gt=start_time
        )
        if overlapping_quizzes.exists():
            raise serializers.ValidationError("This quiz overlaps with another quiz for the same course.")

        return attrs


class QuestionSerializer(serializers.ModelSerializer):
    class Meta:
        model = Question
        fields = ['id', 'quiz', 'question_type', 'question', 'marks', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class MultipleChoiceOptionSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuestionType
        fields = ['id', 'question', 'text', 'is_correct', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class FillInTheBlanksAnswerSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuestionType
        fields = ['id', 'question', 'correct_answer', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']



class TrueFalseAnswerSerializer(serializers.ModelSerializer):
    class Meta:
        model = QuestionType
        fields = ['id', 'question', 'is_true', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']



class OrderingItemSerializer(serializers.ModelSerializer):
    class Meta:
        model = OrderingItem
        fields = ['id', 'question', 'text', 'order', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class ShortAnswerResponseSerializer(serializers.ModelSerializer):
    class Meta:
        model = ShortAnswerResponse
        fields = ['id', 'question', 'correct_response', 'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class StudentAnswerSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentAnswer
        fields = ['id', 'submission', 'question', 'answer_text']
        read_only_fields = ['id']

    def validate_submission(self, value):
        """Check if the submission exists."""
        if not StudentSubmission.objects.filter(id=value.id).exists():
            raise serializers.ValidationError("The specified submission does not exist.")
        return value

    def validate_question(self, value):
        """Check if the question exists."""
        if not Question.objects.filter(id=value.id).exists():
            raise serializers.ValidationError("The specified question does not exist.")
        return value

    def validate_answer_text(self, value):
        """Ensure answer text is not empty."""
        if not value.strip():
            raise serializers.ValidationError("Answer text cannot be empty.")
        return value



# serializers.py



class StudentSubmissionSerializer(serializers.ModelSerializer):
    class Meta:
        model = StudentSubmission
        fields = ['id', 'quiz', 'student_id', 'submitted_at', 'marks_obtained', 'graded']
        read_only_fields = ['id', 'submitted_at', 'marks_obtained', 'graded']

    def validate_quiz(self, value):
        """Check if the quiz exists and is active."""
        if not Quiz.objects.filter(id=value.id).exists():
            raise serializers.ValidationError("The specified quiz does not exist.")
        # Optionally: Check if the quiz is active
        return value

    def validate_student_id(self, value):
        """Ensure that the student ID is valid."""
        # Implement any specific logic to validate student ID format or existence
        # For example, check if it matches a certain UUID format or exists in the user table
        return value
