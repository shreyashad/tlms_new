from django.db import models

from accounts.models import BaseModel
from course.utils import StatusChoice


# Create your models here.

class Badge(BaseModel):
    title = models.CharField(max_length=255)
    description = models.TextField()
    image = models.ImageField(upload_to='badge_images/', blank=True, null=True)
    status = models.CharField(max_length=50, choices=StatusChoice)

    class Meta:
        verbose_name = "Badge"
        verbose_name_plural = "Badges"
        ordering = ['title']


    def __str__(self):
        return self.title


class UserBadge(models.Model):
    user = models.CharField(max_length=250)
    badge = models.ForeignKey(Badge, on_delete=models.CASCADE)
    earned_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f"{self.user.username} - {self.badge.name}"