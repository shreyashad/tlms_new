from rest_framework import serializers
from common.models import *


class ToDaysWisdomSerializer(serializers.ModelSerializer):
    class Meta:
        model = ToDaysWisdom
        fields = ['id', 'topic','created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']



class TrainingRoomsSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrainingRooms
        fields = ['id', 'name', 'capacity', 'is_booked',  'created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class RoomAvailabilitySerializer(serializers.ModelSerializer):
    class Meta:
        model = RoomAvailability
        fields = ['id', 'room', 'date', 'is_available','description','created_at', 'updated_at', 'created_by', 'updated_by']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']


class TrainingRequestSerializer(serializers.ModelSerializer):
    class Meta:
        model = TrainingRequest
        fields = ['id', 'course', 'requester', 'receiver', 'mode', 'team_id', 'additional_notes', 'status']
        read_only_fields = ['id', 'created_at', 'updated_at', 'created_by', 'updated_by']

    def validate(self, attrs):
        # Custom validation logic can go here
        if attrs['mode'] not in dict(TrainingRequest.MODE_CHOICES):
            raise serializers.ValidationError({"mode": "Invalid mode selected."})

        # Add additional validation as necessary
        return attrs