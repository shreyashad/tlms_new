from django.db import models
from uuid import uuid4
from accounts.models import BaseModel
from common.auth_client import AuthServerClient
from course.models import *


class ToDaysWisdom(BaseModel):
    topic = models.TextField()

    class Meta:
        verbose_name = "Today's Wisdom"
        verbose_name_plural = "Today's Wisdoms"
        db_table = "today's_wisdom"
        ordering = ("-created_at",)

    def __str__(self):
        return self.topic


class TrainingRooms(BaseModel):
    name = models.CharField(max_length=100, unique=True)
    capacity = models.PositiveIntegerField()
    is_booked = models.BooleanField(default=False)

    def __str__(self):
        return self.name


class RoomAvailability(BaseModel):
    room = models.ForeignKey(TrainingRooms, on_delete=models.CASCADE)
    date = models.DateField()
    is_available = models.BooleanField(default=True)
    description = models.TextField()

    def __str__(self):
        status = "Available" if self.is_available else "Not Available"
        return f"{self.room} - {self.date} - {status}"




class TrainingRequest(BaseModel):
    MODE_CHOICES = [
        ('online', 'Online'),
        ('offline', 'Offline'),
        ('self-learning', 'Self-learning')
    ]
    REQUEST_STATUS = [
        ('pending', 'Pending'),
        ('approved', 'Approved'),
        ('rejected', 'Rejected')
    ]

    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    requester = models.CharField(max_length=255)  # Store CAS user ID
    receiver = models.CharField(max_length=255)   # Store CAS user ID
    mode = models.CharField(max_length=20, choices=MODE_CHOICES)
    team_id = models.CharField(max_length=255)
    additional_notes = models.TextField(blank=True)
    status = models.CharField(max_length=20, choices=REQUEST_STATUS, default='pending')


    def get_requester_info(self):
        return AuthServerClient.get_user_info(self.requester_username)

    def get_receiver_info(self):
        return AuthServerClient.get_user_info(self.receiver_username)

    def __str__(self):
        return f"{self.course.name} - {self.requester_username} - {self.get_mode_display()}"

class TrainerAvailability(models.Model):
    trainer = models.CharField(max_length=255)
    scheduled_date = models.DateField()
    is_available = models.BooleanField(default=True)

    class Meta:
        unique_together = ['trainer', 'scheduled_date']

class TrainingSchedule(models.Model):
    request = models.OneToOneField(TrainingRequest, on_delete=models.CASCADE, related_name='schedule')
    trainers = models.CharField(max_length=255)
    room = models.ForeignKey(TrainingRooms, related_name='scheduled_trainings', on_delete=models.CASCADE)
    scheduled_date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    duration_hours = models.PositiveIntegerField()
    additional_notes = models.TextField(blank=True)

    def save(self, *args, **kwargs):
        super().save(*args, **kwargs)
        # Mark room as not available for the scheduled date
        RoomAvailability.objects.update_or_create(
            room=self.room,
            date=self.scheduled_date,
            defaults={'is_available': False}
        )
        # Mark trainers as not available for the scheduled date
        for trainer in self.trainers.all():
            TrainerAvailability.objects.update_or_create(trainer=trainer, scheduled_date=self.scheduled_date,
                                                         defaults={'is_available': False})

    def __str__(self):
        return f"{self.request.course.name} - {', '.join([trainer.username for trainer in self.trainers.all()])}"




class TrainingSession(models.Model):
    schedule = models.ForeignKey(TrainingSchedule,on_delete=models.CASCADE)
    start_time = models.DateTimeField()
    location = models.CharField(max_length=100)
    additional_notes = models.TextField(blank=True)

    def __str__(self):
        return f"{self.schedule.request.course.name} - {self.date_time}"


class AttendanceRecord(models.Model):
    session = models.ForeignKey(TrainingSession, on_delete=models.CASCADE)
    participant = models.CharField(max_length=255)
    attendance_time = models.DateTimeField(null=True, blank=True)
    departure_time = models.DateTimeField(null=True, blank=True)
    absent = models.BooleanField(default=False)
    late_arrival = models.BooleanField(default=False)
    toggled_by_trainer = models.BooleanField(default=False)  # Indicates if attendance was toggled by the trainer

    def mark_attendance(self, attendance_time):
        self.attendance_time = attendance_time
        self.toggled_by_trainer = True
        self.save()

    def mark_departure(self, departure_time):
        self.departure_time = departure_time
        self.save()


class BreakTime(models.Model):
    session = models.ForeignKey(TrainingSession, on_delete=models.CASCADE)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    duration_minutes = models.PositiveIntegerField()


class TaskExecution(models.Model):
    session = models.ForeignKey(TrainingSession, on_delete=models.CASCADE)
    task_name = models.CharField(max_length=100)
    executor = models.CharField(max_length=255)
    start_time = models.DateTimeField()
    end_time = models.DateTimeField()
    status = models.CharField(max_length=20)  # e.g., "completed", "pending"



class CourseEnrollment(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    course = models.ForeignKey(Course, on_delete=models.CASCADE)
    enrollment_date = models.DateTimeField(auto_now_add=True)

    class Meta:
        unique_together = ('user', 'course')


class VideoCompletion(models.Model):
    user = models.CharField(max_length=255)
    video = models.ForeignKey(VideoLesson, on_delete=models.CASCADE)
    is_completed = models.BooleanField(default=False)
    completion_time = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('user', 'video')



class ModuleCompletion(models.Model):
    user = models.ForeignKey('auth.User', on_delete=models.CASCADE)
    module = models.ForeignKey(Module, on_delete=models.CASCADE)
    is_completed = models.BooleanField(default=False)
    completion_time = models.DateTimeField(auto_now=True)

    class Meta:
        unique_together = ('user', 'module')
