from django.shortcuts import render

from common.auth_client import AuthServerClient
from common.models import *
from accounts.authentication import CustomCASAuthentication
from rest_framework.permissions import IsAuthenticated
from rest_framework import status, generics,filters
from django_filters.rest_framework import DjangoFilterBackend
from common.serializers import ToDaysWisdomSerializer, TrainingRoomsSerializer, TrainingRequestSerializer
from rest_framework.response import Response

# Create your views here.


# for todays wisdom

class TodaysWisdomListView(generics.ListAPIView):
    queryset = ToDaysWisdom.objects.all()
    serializer_class = ToDaysWisdomSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class TodaysWisdomCreateView(generics.CreateAPIView):
    queryset = ToDaysWisdom.objects.all()
    serializer_class =  ToDaysWisdomSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class TodaysWisdomDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = ToDaysWisdom.objects.all()
    serializer_class = ToDaysWisdomSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


# for Training room

class TrainingRoomListView(generics.ListAPIView):
    queryset = TrainingRooms.objects.all()
    serializer_class = TrainingRoomsSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]


class TrainingRoomCreateView(generics.CreateAPIView):
    queryset = TrainingRooms.objects.all()
    serializer_class =  TrainingRoomsSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_create(self, serializer):
        user = self.request.user
        serializer.save(created_by=user.username, updated_by=user.username)


class TrainingRoomDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = TrainingRooms.objects.all()
    serializer_class = TrainingRoomsSerializer
    authentication_classes = [CustomCASAuthentication]
    permission_classes = [IsAuthenticated]

    def perform_update(self, serializer):
        user = self.request.user
        serializer.save(updated_by=user.username)


class TrainingRequestCreateView(generics.CreateAPIView):
    queryset = TrainingRequest.objects.all()
    serializer_class = TrainingRequestSerializer
    permission_classes = [IsAuthenticated]  # Ensure the user is authenticated
    authentication_classes = [CustomCASAuthentication]

    def create(self, request, *args, **kwargs):
        # Access the authenticated user
        user = request.user  # This comes from the CustomCASAuthentication

        # Validate team info from auth_server using the authenticated user
        team_info = AuthServerClient.get_team_info(request.data.get('team_id'))
        if not team_info:
            return Response({"error": "Invalid team ID."}, status=status.HTTP_400_BAD_REQUEST)

        # Prepare data for training request, using authenticated user's info
        request_data = {
            "course": request.data.get('course'),
            "requester":request.data.get('requester'),  # Use authenticated user's ID
            "receiver": request.data.get('receiver'),  # You may want to set this dynamically
            "mode": request.data.get('mode'),
            "team_id": request.data.get('team_id'),
            "additional_notes": request.data.get('additional_notes'),
        }

        # Create the training request
        serializer = self.get_serializer(data=request_data)
        serializer.is_valid(raise_exception=True)
        self.perform_create(serializer)
        return Response(serializer.data, status=status.HTTP_201_CREATED)


class TrainingRequestListView(generics.ListAPIView):
    queryset = TrainingRequest.objects.all()
    serializer_class = TrainingRequestSerializer
    filter_backends = [DjangoFilterBackend, filters.OrderingFilter]
    filterset_fields = ['status', 'mode', 'requester_id', 'team_id']  # Fields you want to filter on
    ordering_fields = ['status', 'course', 'requester_id', 'created_at']  # Adjust to your model fields
    ordering = ['-created_at']  # Default ordering

    def list(self, request, *args, **kwargs):
        queryset = self.get_queryset()
        serializer = self.get_serializer(queryset, many=True)
        return Response(serializer.data)


class TrainingRequestDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = TrainingRequest.objects.all()
    serializer_class = TrainingRequestSerializer

    def update(self, request, *args, **kwargs):
        # Additional validation logic can be added here if needed
        return super().update(request, *args, **kwargs)

    def destroy(self, request, *args, **kwargs):
        # Optionally, you can add any custom behavior before deletion
        return super().destroy(request, *args, **kwargs)
