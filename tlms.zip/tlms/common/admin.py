from django.contrib import admin
from .models import *
# Register your models here.


@admin.register(ToDaysWisdom)
class ToDaysWisdomAdmin(admin.ModelAdmin):
    list_display = ["topic"]


@admin.register(TrainingRooms)
class TrainingRoomsAdmin(admin.ModelAdmin):
    list_display = ["name","is_booked"]


@admin.register(RoomAvailability)
class RoomAvailabilityAdmin(admin.ModelAdmin):
    list_display = ["room","date" ,"is_available"]


@admin.register(TrainingRequest)
class TrainingRequestAdmin(admin.ModelAdmin):
    list_display = ["course", "requester","receiver","status"]


@admin.register(TrainerAvailability)
class TrainerAvailabilityAdmin(admin.ModelAdmin):
    list_display = ["trainer", "scheduled_date", "is_available"]


@admin.register(TrainingSchedule)
class ToDaysWisdomAdmin(admin.ModelAdmin):
    list_display = ["request", "trainers", "room", "scheduled_date"]


@admin.register(TrainingSession)
class TrainingSessionAdmin(admin.ModelAdmin):
    list_display = ["schedule", "location","start_time"]



@admin.register(AttendanceRecord)
class AttendanceRecordAdmin(admin.ModelAdmin):
    list_display = ["session","attendance_time",]

