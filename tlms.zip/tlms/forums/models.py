from django.db import models
from accounts.models import BaseModel


# Create your models here.


class ForumCategory(BaseModel):
    name = models.CharField(max_length=100)

    def __str__(self):
        return self.name

class Thread(BaseModel):
    title = models.CharField(max_length=255)
    category = models.ForeignKey(ForumCategory, on_delete=models.CASCADE)

    def __str__(self):
        return self.title

class Post(BaseModel):
    thread = models.ForeignKey(Thread, related_name='posts', on_delete=models.CASCADE)
    content = models.TextField()

    def __str__(self):
        return f"Post by {self.created_by.username} in {self.thread.title}"
