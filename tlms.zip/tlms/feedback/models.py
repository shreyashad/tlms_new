from django.db import models

# Create your models here.

FEEDBACK_TYPE_CHOICE= [
    ('Trainer', 'Trainer'),
    ('TRAINING_SESSION', 'Training Session'),
    ('ONLINE_COURSE', 'Online Course'),
    ('ONLINE_TRAINING', 'Online Training'),
]

class Feedback(models.Model):
    feedback_type = models.CharField(max_length=50, choices=FEEDBACK_TYPE_CHOICE)
    user = models.CharField(max_length=255)
    comment = models.TextField()
    rating = models.IntegerField()  # You may use a ratings library for this field
    created_at = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return f'{self.user.username} - {self.course.title}'
